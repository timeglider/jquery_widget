[Wijmo Open](http://wijmo.com/) - Open Source jQuery UI Widgets
================================

It is a complete kit of jQuery UI widgets. Wijmo is an extension to jQuery UI and adds new widgets and features to your arsenal. Every widget was built to jQuery UI's standards and framework. Some widgets like slider and dialog literally extend their counterpart from jQuery UI. Each widget is ThemeRoller-ready and comes styled with our own version of Aristo.

If you want to use Wijmo, go to [wijmo.com](http://wijmo.com) to get started. Or visit the [Wijmo Forum](http://wijmo.com/groups/) for discussions and questions.

Wijmo Open is completely free and open source with no limitations. Wijmo Open can be licensed under the [MIT](http://www.opensource.org/licenses/mit-license.html) or [GPL](http://www.opensource.org/licenses/gpl-2.0.php) licenses. 